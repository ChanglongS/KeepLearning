# author luke
# 2022年02月24日

def receive():
    print('I am receive')
    return 'receive'