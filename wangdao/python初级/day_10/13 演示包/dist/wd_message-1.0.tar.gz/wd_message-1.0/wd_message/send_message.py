# author luke
# 2022年02月24日

def send():
    print('I am send')